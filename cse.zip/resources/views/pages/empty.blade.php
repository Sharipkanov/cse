@extends('layouts.app')

@section('title'){{ $title }}@endsection

@section('page')
    This is empty page!
@endsection