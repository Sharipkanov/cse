<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-middle uk-flex-space-between">
                <div class="uk-margin-top uk-flex uk-flex-middle">
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status warning uk-margin-small-right"></div><small>На исполнении</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status success uk-margin-small-right"></div><small>Исполнено</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status danger uk-margin-small-right"></div><small>Просрочено</small></div>
                </div>
                <div>
                    <?php if(count($users) && !$item_assigned && $item->executor_id == auth()->user()->id && !$item->status): ?>
                        <button class="uk-button uk-button-primary" data-uk-toggle="{target:'#task-toggle',  animation:'uk-animation-slide-right, uk-animation-slide-right'}">Переназначить карточку задания</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(count($users) && !$item_assigned && !$item->status): ?>
                <div id="task-toggle" class="uk-margin-top <?php echo e(($errors->any()) ? '' : ' uk-hidden'); ?>">
                    <form action="<?php echo e(route('page.task.edit', ['task' => $item->id])); ?>" class="uk-form" method="post">
                        <input type="hidden" name="parent_id" value="<?php echo e($item->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php if($users): ?>
                            <div class="uk-form-row">
                                <label class="uk-form-label">Укажите срок исполнения</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select name="executor_id" class="uk-width-1-1">
                                        <option value="">Выберите исполнителя</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>" <?php echo e((old('executor_id') == $user->id) ? 'selected' : ''); ?>><?php echo e($user->last_name); ?> <?php echo e($user->first_name); ?> <?php echo e($user->middle_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->has('executor_id')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('executor_id')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите срок исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" value="<?php echo e(old('execution_date')); ?>" class="uk-width-1-1" name="execution_date" placeholder="Выберите cрок исполнения" data-uk-datepicker="{minDate: '<?php echo e(date('Y-m-d')); ?>', maxDate: '<?php echo e(explode(' ', $item->execution_period)[0]); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_date')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_date')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите время исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text"  value="<?php echo e(old('execution_time')); ?>" class="uk-width-1-1" name="execution_time" placeholder="Выберите время исполнения" data-uk-timepicker="{start: 9, end: 18}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_time')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_time')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Информация задания</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <textarea name="info" rows="10" class="uk-width-1-1" placeholder="Введите текст задания"><?php echo e(old('info')); ?></textarea>
                            </div>
                        </div>
                        <?php if($errors->has('info')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row uk-text-right">
                            <button type="submit" class="uk-button uk-button-success">Переназначить</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <div class="uk-margin-top uk-margin-bottom">
                <div class="uk-form">
                    <h3>Каточка задания № <?php echo e($item->register_number); ?></h3>
                    <hr>
                    <div class="uk-grid uk-grid-width-1-2">
                        <div>
                            <div>
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">Автор</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <p><?php echo e($item->author()->last_name); ?> <?php echo e($item->author()->first_name); ?> <?php echo e($item->author()->middle_name); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">ФИО исполнителя:</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <p><?php echo e($item->executor()->last_name); ?> <?php echo e($item->executor()->first_name); ?> <?php echo e($item->executor()->middle_name); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">Срок исполнения:</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <p><?php echo e($item->execution_period); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">Статус:</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <?php if($item->status == 2): ?>
                                            <div class="status danger"></div>
                                        <?php elseif($item->status == 1): ?>
                                            <div class="status success"></div>
                                        <?php elseif($item->status == 0): ?>
                                            <div class="status warning"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div>
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">Основание:</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <p>
                                            <?php if($item->correspondence_id): ?>
                                                <a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->correspondence_id])); ?>" target="_blank">Просмотреть</a>
                                            <?php else: ?>
                                                Не имеется
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <div class="uk-grid">
                                    <div class="uk-width-2-6">
                                        <p class="uk-text-bold">Информация задания</p>
                                    </div>
                                    <div class="uk-width-4-6">
                                        <p><?php echo e($item->info); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($item_assigned): ?>
                <div class="uk-margin-top uk-margin-bottom">
                    <div class="uk-form">
                        <h3>Каточка задания № <?php echo e($item_assigned->register_number); ?></h3>
                        <hr>
                        <div class="uk-grid uk-grid-width-1-2">
                            <div>
                                <div>
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">Автор</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <p><?php echo e($item_assigned->author()->last_name); ?> <?php echo e($item_assigned->author()->first_name); ?> <?php echo e($item_assigned->author()->middle_name); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-top">
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">ФИО исполнителя:</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <p><?php echo e($item_assigned->executor()->last_name); ?> <?php echo e($item_assigned->executor()->first_name); ?> <?php echo e($item_assigned->executor()->middle_name); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-top">
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">Срок исполнения:</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <p><?php echo e($item_assigned->execution_period); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-top">
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">Статус:</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <?php if($item_assigned->status == 2): ?>
                                                <div class="status danger"></div>
                                            <?php elseif($item_assigned->status == 1): ?>
                                                <div class="status success"></div>
                                            <?php elseif($item_assigned->status == 0): ?>
                                                <div class="status warning"></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div>
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">Основание:</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <p>
                                                <?php if($item_assigned->correspondence_id): ?>
                                                    <a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->correspondence_id])); ?>" target="_blank">Просмотреть</a>
                                                <?php else: ?>
                                                    Не имеется
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-top">
                                    <div class="uk-grid">
                                        <div class="uk-width-2-6">
                                            <p class="uk-text-bold">Информация задания</p>
                                        </div>
                                        <div class="uk-width-4-6">
                                            <p><?php echo e($item_assigned->info); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>