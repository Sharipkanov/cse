<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-text-right">
                <a href="<?php echo e(route('page.document.list')); ?>" class="uk-button uk-button-primary">К списку экспертиз</a>
            </div>

            <form action="<?php echo e(route('page.expertise.store')); ?>" class="uk-form uk-margin-top uk-margin-large-bottom" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <h3><?php echo e($title); ?></h3>
                    <hr>
                    <div class="uk-form-row">
                        <div class="uk-grid uk-grid-width-1-2">
                            <div>
                                <div>
                                    <label class="uk-form-label">Фабула</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <textarea name="info" class="uk-width-1-1<?php echo e($errors->has('info') ? ' uk-form-danger' : ''); ?>" rows="7" placeholder="Заполните фабулу"><?php echo e(old('info')); ?></textarea>
                                    </div>
                                </div>
                                <?php if($errors->has('info')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Приложения</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="file" name="files[]" multiple>
                                    </div>
                                </div>
                                <?php if($errors->has('files')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('files')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Категория дела:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1<?php echo e(($errors->has('category_id')) ? ' uk-form-danger' : ''); ?>" name="category_id">
                                            <option value="" <?php echo e((old('category_id') == '') ? 'selected' : ''); ?> disabled>Выберите категорию дела</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo e((old('category_id') == $category->id) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('category_id')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('category_id')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">№ дела:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="text" placeholder="Введите номер дела" class="uk-width-1-1<?php echo e($errors->has('case_number') ? ' uk-form-danger' : ''); ?>" name="case_number" value="<?php echo e(old('case_number')); ?>">
                                    </div>
                                </div>
                                <?php if($errors->has('case_number')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('case_number')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">№ статьи:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="text" placeholder="Введите номер статьи" class="uk-width-1-1<?php echo e($errors->has('article_number') ? ' uk-form-danger' : ''); ?>" name="article_number" value="<?php echo e(old('article_number')); ?>">
                                    </div>
                                </div>
                                <?php if($errors->has('article_number')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('article_number')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Первичный статус:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1<?php echo e(($errors->has('expertise_primary_status')) ? ' uk-form-danger' : ''); ?>" name="expertise_primary_status">
                                            <option value="" <?php echo e((old('expertise_primary_status') == '') ? 'selected' : ''); ?> disabled>Выберите первичный статус</option>
                                            <?php $__currentLoopData = $statuses[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->id); ?>" <?php echo e((old('expertise_primary_status') == $status->id) ? 'selected' : ''); ?>><?php echo e($status->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php unset($status); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_primary_status')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_primary_status')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Статус:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1<?php echo e(($errors->has('expertise_status')) ? ' uk-form-danger' : ''); ?>" name="expertise_status">
                                            <option value="" <?php echo e((old('expertise_status') == '') ? 'selected' : ''); ?> disabled>Выберите статус</option>
                                            <?php $__currentLoopData = $statuses[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->id); ?>" <?php echo e((old('expertise_status') == $status->id) ? 'selected' : ''); ?>><?php echo e($status->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php unset($status); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_status')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_status')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Дополнительный статус:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1<?php echo e(($errors->has('expertise_additional_status')) ? ' uk-form-danger' : ''); ?>" name="expertise_additional_status">
                                            <option value="" <?php echo e((old('expertise_additional_status') == '') ? 'selected' : ''); ?> disabled>Выберите дополнительный статус</option>
                                            <?php $__currentLoopData = $statuses[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status->id); ?>" <?php echo e((old('expertise_additional_status') == $status->id) ? 'selected' : ''); ?>><?php echo e($status->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php unset($status); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_additional_status')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_additional_status')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top uk-position-relative">
                                    <label class="uk-form-label">Шифр экспертизы:</label>
                                    <div class="uk-form-controls uk-margin-small-top uk-position-relative">
                                        <input id="speciality-search-input" type="text" placeholder="Введите шифр или название экспертизы" class="uk-width-1-1<?php echo e($errors->has('expertise_speciality_ids') ? ' uk-form-danger' : ''); ?>" name="" >
                                        <input id="speciality-input" type="hidden" name="expertise_speciality_ids" value="<?php echo e(old('expertise_speciality_ids')); ?>">
                                    </div>
                                    <div id="specialities-drop-down" class="drop-down">
                                    </div>
                                    <ul id="specialities-list" class="uk-list">
                                        <?php if(old('expertise_speciality_ids')): ?>
                                            <?php $specialities = Expertise::specialities(old('expertise_speciality_ids')); ?>
                                            <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><span><?php echo e($speciality->code . ' - ' . $speciality->name); ?></span><a href="#" class="speciality-remove" data-id="<?php echo e($speciality->id); ?>" data-code="<?php echo e($speciality->code); ?>"><i class="uk-icon-remove"></i></a></li>
                                                <?php unset($speciality); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php unset($specialities); ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <?php if($errors->has('expertise_speciality_ids')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_speciality_ids')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div>
                                <div>
                                    <label class="uk-form-label">Регион назначивший экспертизу:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1<?php echo e(($errors->has('expertise_region_id')) ? ' uk-form-danger' : ''); ?>" name="expertise_region_id" id="expertise-region-select">
                                            <option value="" <?php echo e((old('expertise_region_id') == '') ? 'selected' : ''); ?> disabled>Выберите регион назначивший экспертизу</option>
                                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($region->id); ?>" <?php echo e((old('expertise_region_id') == $region->id) ? 'selected' : ''); ?>><?php echo e($region->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_region_id')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_region_id')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Наименование органа:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select id="expertise-agency-select" class="uk-width-1-1<?php echo e(($errors->has('expertise_agency_id')) ? ' uk-form-danger' : ''); ?>" name="expertise_agency_id" <?php echo e((old('expertise_agency_id') == '') ? 'disabled' : ''); ?>>
                                            <option value="" <?php echo e((old('expertise_agency_id') == '') ? 'selected' : ''); ?> disabled>Выберите наименование органа</option>
                                            <?php if(old('expertise_agency_id')): ?>
                                                <?php $agencies = Expertise::agencies(old('expertise_region_id')); ?>
                                                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($agency->id); ?>" <?php echo e((old('expertise_agency_id') == $agency->id) ? 'selected' : ''); ?>><?php echo e($agency->name); ?></option>
                                                    <?php unset($agency); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php unset($agencies); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_agency_id')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_agency_id')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top">
                                    <label class="uk-form-label">Орган назначивший экспертизу:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select id="expertise-organ-select" class="uk-width-1-1<?php echo e(($errors->has('expertise_organ_id')) ? ' uk-form-danger' : ''); ?>" name="expertise_organ_id">
                                            <option value="" <?php echo e((old('expertise_organ_id') == '') ? 'selected' : ''); ?> disabled>Выберите орган назначивший экспертизу</option>
                                            <?php $__currentLoopData = $organs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($organ->id); ?>" <?php echo e((old('expertise_organ_id') == $organ->id) ? 'selected' : ''); ?>><?php echo e($organ->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_organ_id')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_organ_id')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top<?php echo e((old('expertise_organ_id') == 1) ? '' : ' uk-hidden'); ?>" id="expertise-organ-name">
                                    <label class="uk-form-label">Введите название органа:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="text" placeholder="Введите номер дела" class="uk-width-1-1<?php echo e($errors->has('expertise_organ_name') ? ' uk-form-danger' : ''); ?>" name="expertise_organ_name" value="<?php echo e(old('expertise_organ_name')); ?>">
                                    </div>
                                </div>
                                <div class="uk-margin-top">
                                    <span class="uk-h4">Данные лица назначившего экспертизу</span>
                                </div>
                                <div class="uk-margin-top expertise-extra-fields" id="expertise-user-fullname">
                                    <label class="uk-form-label">ФИО:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="text" placeholder="ФИО лица назначевшего экспертизу" class="uk-width-1-1<?php echo e($errors->has('expertise_user_fullname') ? ' uk-form-danger' : ''); ?>" name="expertise_user_fullname" value="<?php echo e(old('expertise_user_fullname')); ?>">
                                    </div>
                                </div>
                                <?php if($errors->has('expertise_user_fullname')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expertise_user_fullname')); ?></p>
                                <?php endif; ?>
                                <div class="uk-margin-top expertise-extra-fields" id="expertise-user-position">
                                    <label class="uk-form-label">Должность:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <input type="text" placeholder="Должность лица назначевшего экспертизу" class="uk-width-1-1<?php echo e($errors->has('expertise_user_position') ? ' uk-form-danger' : ''); ?>" name="expertise_user_position" value="<?php echo e(old('expertise_user_position')); ?>">
                                    </div>
                                </div>
                                <div class="uk-margin-top expertise-extra-fields" id="expertise-user-rank">
                                    <label class="uk-form-label">Звание:</label>
                                    <div class="uk-form-controls uk-margin-small-top">
                                        <select class="uk-width-1-1" name="expertise_user_rank">
                                            <option value="" <?php echo e((old('expertise_user_rank') == '') ? 'selected' : ''); ?> disabled>Выберите звание лица назначевшего экспертизу</option>
                                            <option value="Лейтенант" <?php echo e((old('expertise_user_rank') == 'Лейтенант') ? 'selected' : ''); ?>>Лейтенант</option>
                                            <option value="Cтарший лейтенант" <?php echo e((old('expertise_user_rank') == 'Cтарший лейтенант') ? 'selected' : ''); ?>>Cтарший лейтенант</option>
                                            <option value="Капитан" <?php echo e((old('expertise_user_rank') == 'Капитан') ? 'selected' : ''); ?>>Капитан</option>
                                            <option value="Майор" <?php echo e((old('expertise_user_rank') == 'Майор') ? 'selected' : ''); ?>>Майор</option>
                                            <option value="Подполковник" <?php echo e((old('expertise_user_rank') == 'Подполковник') ? 'selected' : ''); ?>>Подполковник</option>
                                            <option value="Полковник" <?php echo e((old('expertise_user_rank') == 'Полковник') ? 'selected' : ''); ?>>Полковник</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="uk-text-right">
                        <button type="submit" class="uk-button uk-button-success">Создать документ</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>