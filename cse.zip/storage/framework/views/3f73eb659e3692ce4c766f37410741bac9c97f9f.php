<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <form action="<?php echo e(route('page.correspondence.store')); ?>" class="uk-form uk-margin-top uk-margin-large-bottom" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <h3><?php echo e($title); ?></h3>
                    <hr>
                    <div class="uk-grid uk-grid-width-1-2">
                        <div>
                            <div>
                                <label class="uk-form-label">Язык обращения:</label>
                                <div class="uk-form-controls uk-margin-small-top uk-flex">
                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="<?php echo e(($loop->first) ? 'uk-margin-right' : ''); ?>">
                                            <label class="uk-flex uk-flex-middle">
                                        <span class="uk-margin-small-right">
                                            <input type="radio" name="language_id" value="<?php echo e($language->id); ?>" <?php echo e((old('language_id') == $language->id) ? 'checked' : ''); ?>>
                                        </span>
                                                <span><?php echo e($language->name); ?></span>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php if($errors->has('language_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('language_id')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top uk-position-relative">
                                <label class="uk-form-label">Корреспондент:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" name="" id="correspondent-search-input" placeholder="Введите имя корреспондента" class="uk-width-1-1<?php echo e(($errors->has('correspondent_id')) ? ' uk-form-danger' : ''); ?>">
                                    <input type="hidden" name="correspondent_id"  value="" id="correspondent-input">
                                </div>
                                <div class="drop-down" id="correspondent-drop-down">

                                </div>
                            </div>
                            <?php if($errors->has('correspondent_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('correspondent_id')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">ФИО исполнителя:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input name="executor_fullname" class="uk-width-1-1<?php echo e($errors->has('executor_fullname') ? ' uk-form-danger' : ''); ?>" value="<?php echo e(old('info')); ?>" placeholder="Введите ФИО исполнителя">
                                </div>
                            </div>
                            <?php if($errors->has('executor_fullname')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('executor_fullname')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Исходящий №:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input name="outcome_number" class="uk-width-1-1<?php echo e($errors->has('outcome_number') ? ' uk-form-danger' : ''); ?>" value="<?php echo e(old('info')); ?>" placeholder="Введите исходящий номер">
                                </div>
                            </div>
                            <?php if($errors->has('outcome_number')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('outcome_number')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Дата исходящего:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1<?php echo e($errors->has('outcome_date') ? ' uk-form-danger' : ''); ?>" name="outcome_date" placeholder="Выберите дату исходящего" name="date" data-uk-datepicker="{maxDate: '<?php echo e(date('Y-m-d')); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                                </div>
                            </div>
                            <?php if($errors->has('outcome_date')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('outcome_date')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Срок исполнения:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1" name="execution_period" placeholder="Выберите cрок исполнения" data-uk-datepicker="{minDate: '<?php echo e(date('Y-m-d')); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                                </div>
                            </div>
                            <?php if($errors->has('execution_period')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_period')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Страницы:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input name="pages" class="uk-width-1-1<?php echo e($errors->has('pages') ? ' uk-form-danger' : ''); ?>" value="<?php echo e(old('info')); ?>" placeholder="Введите количество страниц">
                                </div>
                            </div>
                            <?php if($errors->has('pages')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('pages')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Приложения</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="file" name="files[]" multiple>
                                </div>
                            </div>
                            <?php if($errors->has('files')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('files')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="uk-position-relative">
                                <label class="uk-form-label">Ответ на исходящий:</label>
                                <div class="uk-form-controls uk-margin-small-top uk-position-relative">
                                    <input id="correspondence-search-input" type="text" placeholder="Введите шифр или название экспертизы" class="uk-width-1-1<?php echo e($errors->has('reply_correspondence_id') ? ' uk-form-danger' : ''); ?>" >
                                    <input type="hidden" name="reply_correspondence_id" id="correspondence-input">
                                </div>
                                <div id="correspondence-drop-down" class="drop-down">
                                </div>
                                <ul id="specialities-list" class="uk-list">
                                </ul>
                            </div>
                            <div class="uk-margin-top ">
                                <label class="uk-form-label">Получатель:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" value="Бекжанов Ж.Л" disabled class="uk-width-1-1">
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <label class="uk-form-label">Тип документа</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select class="uk-width-1-1<?php echo e($errors->has('document_type_id') ? ' uk-form-danger' : ''); ?>" name="document_type_id">
                                        <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($documentType->id); ?>" <?php echo e((old('document_type_id') == $documentType->id) ? 'selected' : ''); ?>><?php echo e($documentType->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php if($errors->has('document_type_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('document_type_id')); ?></p>
                            <?php endif; ?>
                            <input type="hidden" name="is_income" value="1">
                        </div>
                    </div>
                    <hr>
                    <div class="uk-text-right">
                        <button type="submit" class="uk-button uk-button-success">Создать карточку</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>