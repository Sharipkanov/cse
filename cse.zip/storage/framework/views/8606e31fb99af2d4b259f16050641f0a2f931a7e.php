<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <?php
        $expertiseInfoCreatedDate = explode(' ', $expertiseInfo->created_at)[0];
        $expertiseUntilSuspensionDate = date('Y-m-d', strtotime($expertiseInfoCreatedDate.' + 5 days'));
        $expertiseOutOfSuspension = strtotime($expertiseUntilSuspensionDate) <= time();
    ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                    <?php if(!$expertiseInfo->is_stopped): ?>
                        <form action="<?php echo e(route('page.expertise.approve', ['expertiseInfo' => $expertiseInfo->id])); ?>" class="uk-display-inline" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="uk-button uk-button-primary">Соглосовать</button>
                        </form>
                        <?php if(!$expertiseOutOfSuspension): ?>
                            <button class="uk-button uk-button-danger" data-uk-toggle="{target:'#suspension', animation:'uk-animation-slide-right, uk-animation-slide-right'}">Приостановить</button>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($expertiseInfo->is_stopped && !count($approves)): ?>
                        <form action="<?php echo e(route('page.expertise.restart', ['expertiseInfo' => $expertiseInfo->id])); ?>" class="uk-display-inline" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="uk-button uk-button-success">Возобновть</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('page.expertise.list')); ?>" class="uk-button uk-button-primary">К списку экспертиз</a>
                </div>
            </div>

            <?php if(!$expertiseOutOfSuspension && !$expertiseInfo->is_stopped): ?>
                <div id="suspension" class="uk-form uk-margin-top uk-hidden">
                    <div class="uk-form-row">
                        <label class="uk-form-label">Причина приостановления:</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <select class="uk-width-1-1" name="reason_for_suspension" id="reason_for_suspension">
                                <option value="" selected disabled>Выберите причину приостановления:</option>
                                <option value="Ходатайство">Ходатайство</option>
                                <option value="Командировка">Командировка</option>
                                <option value="Больничный лист">Больничный лист</option>
                                <option value="Вызов в суд">Вызов в суд</option>
                                <option value="Участие в комплексной экспертизе">Участие в комплексной экспертизе</option>
                            </select>
                        </div>

                        <form id="form-sc" action="<?php echo e(route('page.expertise.stop', ['expertiseInfo' => $expertiseInfo->id])); ?>" class="uk-margin-top uk-hidden" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="reason_for_suspension" class="reason_for_suspension">
                            <div class="uk-position-relative">
                                <label class="uk-form-label">Выберите основание:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" name="" id="sc-search-input" placeholder="Введите номер входящего документа корреспондений" class="uk-width-1-1">
                                    <input type="hidden" name="correspondence_id"  value="" id="sc-input">
                                </div>
                                <div class="drop-down" id="sc-drop-down">

                                </div>
                            </div>
                            <div class="uk-margin-top uk-text-right">
                                <button class="uk-button uk-button-success">Приостоновить</button>
                            </div>
                        </form>

                        <form id="form-ds" action="<?php echo e(route('page.expertise.stop', ['expertiseInfo' => $expertiseInfo->id])); ?>" class="uk-margin-top uk-hidden" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="reason_for_suspension" class="reason_for_suspension">
                            <div class="uk-position-relative">
                                <label class="uk-form-label">Выберите основание:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" name="" id="ds-search-input" placeholder="Введите номер документа" class="uk-width-1-1">
                                    <input type="hidden" name="document_id"  value="" id="ds-input">
                                </div>
                                <div class="drop-down" id="ds-drop-down">

                                </div>
                            </div>
                            <div class="uk-margin-top uk-text-right">
                                <button class="uk-button uk-button-success">Приостоновить</button>
                            </div>
                        </form>

                        <div>
                            
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(count($approves)): ?>
                <div class="uk-margin-top uk-form">
                    <?php $__currentLoopData = $approves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e((!$loop->first) ? 'uk-margin-top' : ''); ?>">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold"><?php echo e($approve->approver()->last_name .' '. str_limit($approve->approver()->first_name, 1, '.') . str_limit($approve->approver()->middle_name, 1, '')); ?></p>
                                </div>
                                <div class="uk-width-4-6">
                                    <?php if($approve->status == 0): ?>
                                        <p>Ожидает</p>
                                    <?php elseif($approve->status == 1): ?>
                                        <p>Соглосован</p>
                                    <?php elseif($approve->status == 2): ?>
                                        <p>Соглосован с примичанием</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php elseif($approve->status == 3): ?>
                                        <p>Отклонен</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="uk-accordion uk-margin-top uk-margin-bottom" data-uk-accordion="{showfirst: false}">

                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3 uk-accordion-title">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>
                <div class="uk-accordion-content uk-form">
                    <div>
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Делопроизводитель</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->author()->last_name); ?> <?php echo e($item->author()->first_name); ?> <?php echo e($item->author()->middle_name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Фабула</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->info); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Приложения</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if(count($item->fileList)): ?>
                                    <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Нет вложенных файлов</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Категория дела:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->category()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">№ дела:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->case_number); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">№ статьи:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->article_number); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Статус:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->status()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Дополнительный статус:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->addition_status()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Шифр экспертизы:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <ul class="uk-list">
                                    <?php $__currentLoopData = $item->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><span><?php echo e($speciality->code .' - '. $speciality->name); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Регион назначивший экспертизу:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->region()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Наименование органа:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->agency()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Орган назначивший экспертизу:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->organ()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <?php if($item->expertise_organ_name): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Введите название органа:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_organ_name); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <div class="">
                        <span class="uk-h4">Данные лица назначевшего экспертизу</span>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">ФИО:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->expertise_user_fullname); ?></p>
                            </div>
                        </div>
                    </div>


                    <?php if($item->expertise_user_position): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Должность:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_user_position); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($item->expertise_user_rank): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Звание:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_user_rank); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($item->status != 0): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Статус</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p class="fw-flex fw-flex-middle">
                                        <?php if($item->status == 2): ?>
                                            <span class="status success uk-margin-small-right"></span>
                                            <span>Завершен</span>
                                        <?php elseif($item->status == 1): ?>
                                            <span class="status warning uk-margin-small-right"></span>
                                            <span>В процесе</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <form action="<?php echo e(route('page.expertise.update', ['expertiseInfo' => $expertiseInfo->id])); ?>" class="uk-form uk-margin-bottom" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="uk-grid uk-grid-width-1-2">
                    <div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Категория сложности:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <select class="uk-width-1-1" name="category_of_difficulty">
                                    <option value="" <?php echo e((!$expertiseInfo->category_of_difficulty) ? 'selected' : ''); ?> disabled>Выберите категорию сложности:</option>
                                    <option value="Простая" <?php echo e(($expertiseInfo->category_of_difficulty == 'Простая') ? 'selected' : ''); ?>>Простая</option>
                                    <option value="Средней степени сложности" <?php echo e(($expertiseInfo->category_of_difficulty == 'Средней степени сложности') ? 'selected' : ''); ?>>Средней степени сложности</option>
                                    <option value="Сложная" <?php echo e(($expertiseInfo->category_of_difficulty == 'Сложная') ? 'selected' : ''); ?>>Сложная</option>
                                    <option value="Особо сложная" <?php echo e(($expertiseInfo->category_of_difficulty == 'Особо сложная') ? 'selected' : ''); ?>>Особо сложная</option>
                                </select>
                            </div>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Количество поставленных вопросов:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество поставленных вопросов" class="uk-width-1-1<?php echo e($errors->has('questions_count') ? ' uk-form-danger' : ''); ?>" name="questions_count" value="<?php echo e(($expertiseInfo->questions_count) ? $expertiseInfo->questions_count : ''); ?>">
                            </div>
                            <?php if($errors->has('questions_count')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('questions_count')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Количество объектов :</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество объектов" class="uk-width-1-1<?php echo e($errors->has('objects_count') ? ' uk-form-danger' : ''); ?>" name="objects_count" value="<?php echo e(($expertiseInfo->objects_count) ? $expertiseInfo->objects_count : ''); ?>">
                            </div>
                            <?php if($errors->has('objects_count')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('objects_count')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Срок производства:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" value="<?php echo e(($expertiseInfo->expiration_date) ? $expertiseInfo->expiration_date : ''); ?>" class="uk-width-1-1<?php echo e($errors->has('expiration_date') ? ' uk-form-danger' : ''); ?>" name="expiration_date" placeholder="Укажите cрок производства" data-uk-datepicker="{minDate: '<?php echo e($expertiseInfoCreatedDate); ?>', maxDate: '<?php echo e(date('Y-m-d', strtotime($expertiseInfoCreatedDate.' + 30 days'))); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                            </div>
                            <?php if($errors->has('expiration_date')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('expiration_date')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Результата исследования:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <select class="uk-width-1-1" name="result_of_research">
                                    <option value="" <?php echo e((!$expertiseInfo->result_of_research) ? 'selected' : ''); ?> disabled>Выберите результата исследования:</option>
                                    <option value="Заключение" <?php echo e(($expertiseInfo->result_of_research == 'Заключение') ? 'selected' : ''); ?>>Заключение</option>
                                    <option value="СНДЗ" <?php echo e(($expertiseInfo->result_of_research == 'СНДЗ') ? 'selected' : ''); ?>>СНДЗ</option>
                                    <option value="Возврат без исполнения" <?php echo e(($expertiseInfo->result_of_research == 'Возврат без исполнения') ? 'selected' : ''); ?>>Возврат без исполнения</option>
                                </select>
                            </div>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Категорические выводы:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите категорические выводы" class="uk-width-1-1<?php echo e($errors->has('categorical_conclusions') ? ' uk-form-danger' : ''); ?>" name="categorical_conclusions" value="<?php echo e(($expertiseInfo->categorical_conclusions) ? $expertiseInfo->categorical_conclusions : ''); ?>">
                            </div>
                            <?php if($errors->has('categorical_conclusions')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('categorical_conclusions')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Вероятные выводы:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите вероятные выводы" class="uk-width-1-1<?php echo e($errors->has('probable_conclusions') ? ' uk-form-danger' : ''); ?>" name="probable_conclusions" value="<?php echo e(($expertiseInfo->probable_conclusions) ? $expertiseInfo->probable_conclusions : ''); ?>">
                            </div>
                            <?php if($errors->has('probable_conclusions')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('probable_conclusions')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">НПВ:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите НПВ" class="uk-width-1-1<?php echo e($errors->has('wnp') ? ' uk-form-danger' : ''); ?>" name="wnp" value="<?php echo e(($expertiseInfo->wnp) ? $expertiseInfo->wnp : ''); ?>">
                            </div>
                            <?php if($errors->has('wnp')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('wnp')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Количество не решенных вопросов :</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество не решенных вопросов " class="uk-width-1-1<?php echo e($errors->has('unsolved_issues_count') ? ' uk-form-danger' : ''); ?>" name="unsolved_issues_count" value="<?php echo e(($expertiseInfo->unsolved_issues_count) ? $expertiseInfo->unsolved_issues_count : ''); ?>">
                            </div>
                            <?php if($errors->has('unsolved_issues_count')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('unsolved_issues_count')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Дано выводов (ВСЕГО):</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество" class="uk-width-1-1<?php echo e($errors->has('conclusions_count') ? ' uk-form-danger' : ''); ?>" name="conclusions_count" value="<?php echo e(($expertiseInfo->conclusions_count) ? $expertiseInfo->conclusions_count : ''); ?>">
                            </div>
                            <?php if($errors->has('conclusions_count')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('conclusions_count')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Категорические выводы (ПОЛОЖИТЕЛЬНЫЕ):</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество" class="uk-width-1-1<?php echo e($errors->has('categorical_conclusions_positive') ? ' uk-form-danger' : ''); ?>" name="categorical_conclusions_positive" value="<?php echo e(($expertiseInfo->categorical_conclusions_positive) ? $expertiseInfo->categorical_conclusions_positive : ''); ?>">
                            </div>
                            <?php if($errors->has('categorical_conclusions_positive')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('categorical_conclusions_positive')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Категорические выводы (ОТРИЦАТЕЛЬНЫЕ):</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите количество" class="uk-width-1-1<?php echo e($errors->has('categorical_conclusions_negative') ? ' uk-form-danger' : ''); ?>" name="categorical_conclusions_negative" value="<?php echo e(($expertiseInfo->categorical_conclusions_negative) ? $expertiseInfo->categorical_conclusions_negative : ''); ?>">
                            </div>
                            <?php if($errors->has('categorical_conclusions_negative')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('categorical_conclusions_negative')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Стоимость исследования:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input data-number type="text" placeholder="Укажите стоимость исследования " class="uk-width-1-1<?php echo e($errors->has('cost') ? ' uk-form-danger' : ''); ?>" name="cost" value="<?php echo e(($expertiseInfo->cost) ? $expertiseInfo->cost : ''); ?>">
                            </div>
                            <?php if($errors->has('cost')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('cost')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Отметка об оплате:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <select class="uk-width-1-1" name="payment_note">
                                    <option value="" disabled <?php echo e((!$expertiseInfo->payment_note) ? 'selected' : ''); ?>>Выберите отметку об оплате:</option>
                                    <option value="Платежное поручение" <?php echo e(($expertiseInfo->payment_note == 'Платежное поручение') ? 'selected' : ''); ?>>Платежное поручение</option>
                                    <option value="Приходный кассовый ордер" <?php echo e(($expertiseInfo->payment_note == 'Приходный кассовый ордер') ? 'selected' : ''); ?>>Приходный кассовый ордер</option>
                                </select>
                            </div>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">№ документа:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" placeholder="Укажите номер документа" class="uk-width-1-1<?php echo e($errors->has('payment_note_document_number') ? ' uk-form-danger' : ''); ?>" name="payment_note_document_number" value="<?php echo e(($expertiseInfo->payment_note_document_number) ? $expertiseInfo->payment_note_document_number : ''); ?>">
                            </div>
                            <?php if($errors->has('payment_note_document_number')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('payment_note_document_number')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Дата документа:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input value="<?php echo e(($expertiseInfo->payment_note_document_date) ? $expertiseInfo->payment_note_document_date : ''); ?>" type="text" class="uk-width-1-1<?php echo e($errors->has('payment_note_document_date') ? ' uk-form-danger' : ''); ?>" name="payment_note_document_date" placeholder="Выберите дату документа" data-uk-datepicker="{minDate: '<?php echo e(date('Y-m-d')); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                            </div>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Причины возврата без исполнения:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <textarea name="return_reason" class="uk-width-1-1<?php echo e($errors->has('return_reason') ? ' uk-form-danger' : ''); ?>" rows="7" placeholder="Укажите причину возврата без исполнения"><?php echo e($expertiseInfo->return_reason); ?></textarea>
                            </div>
                        </div>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Причины СНДЗ:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <textarea name="rigs" class="uk-width-1-1<?php echo e($errors->has('rigs') ? ' uk-form-danger' : ''); ?>" rows="7" placeholder="Укажите причины СНДЗ"><?php echo e($expertiseInfo->rigs); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($expertiseInfo->status == 0 && !$expertiseInfo->is_stopped): ?>
                <hr>
                <div class="uk-text-right">
                    <button type="submit" class="uk-button uk-button-success">Сохранить</button>
                </div>
                <?php endif; ?>
            </form>
            <div class="uk-form uk-margin-large-bottom">
                <div>
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата приостановления</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->suspension_date) ? $expertiseInfo->suspension_date : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Причина приостановления</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->reason_for_suspension) ? $expertiseInfo->reason_for_suspension : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($expertiseInfo->document_id || $expertiseInfo->correspondence_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Основание</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if($expertiseInfo->document_id): ?>
                                    <a target="_blank" href="<?php echo e(route('page.document.show', ['document' => $expertiseInfo->document_id])); ?>">Просмотреть</a>
                                <?php endif; ?>
                                <?php if($expertiseInfo->correspondence_id): ?>
                                    <a target="_blank" href="<?php echo e(route('page.correspondence.show', ['correspondence' => $expertiseInfo->correspondence_id])); ?>">Просмотреть</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата возобновления </p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->renewal_date) ? $expertiseInfo->renewal_date : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата завершения исследования </p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->finish_date) ? $expertiseInfo->finish_date : 'Будет указано после завершения экспертизы'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Фактическое количество дней нахождения материалов в территориальном подразделении</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->actual_days) ? $expertiseInfo->actual_days : 'Экспертиза еще не была завершена'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Количество дней в производстве</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->production_days) ? $expertiseInfo->production_days : 'Экспертиза еще не была завершена'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>