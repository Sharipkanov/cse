<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <?php echo $__env->make('includes.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="uk-margin-top uk-width-1-1">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-middle uk-flex-space-between">
                <div class="uk-flex uk-flex-middle">
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status uk-margin-small-right"></div><small>Зарегистрирован (Не присвоен)</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status warning uk-margin-small-right"></div><small>На регистраций</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status success uk-margin-small-right"></div><small>Зарегистрирован</small></div>
                </div>
                <div>
                    <?php if(auth()->user()->position_id == 4): ?>
                        <?php if($type == 'income'): ?>
                            <a href="<?php echo e(route('page.correspondence.income.create')); ?>" class="uk-button uk-button-success">Создать регистрационную карточку входящего документа</a>
                        <?php endif; ?>
                        <button class="uk-button uk-button-primary" data-uk-toggle="{target:'#register-number', animation:'uk-animation-slide-right, uk-animation-slide-right'}">Зарезервировать номер</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="uk-container uk-container-center">
        <form action="<?php echo e(route('page.correspondence.correspondent.store')); ?>" class="uk-form uk-margin-top<?php echo e(($errors->has('name')) ? '' : ' uk-hidden'); ?>" id="add-correspondent" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="store_correspondent" value="1">
            <div>
                <label>Имя корреспондента</label>
                <div class="uk-margin-small-top">
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="uk-width-1-1">
                </div>
            </div>
            <?php if($errors->has('name')): ?>
                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('name')); ?></p>
            <?php endif; ?>
            <div class="uk-margin-top uk-text-right">
                <button class="uk-button uk-button-success">Добавить</button>
            </div>
        </form>
    </div>

    <?php if(auth()->user()->position_id == 4): ?>
        <div class="uk-container uk-container-center uk-hidden" id="register-number">
            <form action="<?php echo e(route('page.number.register')); ?>" class="uk-margin-top uk-form" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="is_income" value="<?php echo e(($type == 'income') ? 1 : 0); ?>">
                <div>
                    <label>Количество номеров</label>
                    <div class="uk-margin-small-top">
                        <input type="text" name="count" value="<?php echo e(old('count')); ?>" class="uk-width-1-1">
                    </div>
                </div>
                <?php if($errors->has('count')): ?>
                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('count')); ?></p>
                <?php endif; ?>
                <div class="uk-margin-top uk-text-right">
                    <button class="uk-button uk-button-success">Зарезервировать</button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="uk-width-1-1 uk-margin-top uk-margin-bottom">
        <div class="uk-container uk-container-center">

            <?php if(count($items)): ?>
                <table class="uk-table uk-table-condensed">
                    <thead>
                        <tr>
                            <th class="width-content">Регистрационный номер</th>
                            <th>ФИО исполнителя</th>
                            <th class="width-content">Корреспондент</th>
                            <th class="width-content">Дата регистрации</th>
                            <th class="width-content"></th>
                            <th class="width-content"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="width-content"><?php echo e($item->register_number); ?></td>
                                <td><?php echo e($item->executor_fullname); ?></td>
                                <td class="width-content"><?php echo e($item->correspondent()->name); ?></td>
                                <td class="width-content"><?php echo e($item->created_at); ?></td>
                                <td class="width-content uk-text-center">
                                    <?php if($item->status == 3): ?>
                                        <span class="status success uk-margin-small-right"></span>
                                    <?php elseif($item->status == 2): ?>
                                        <span class="status warning uk-margin-small-right"></span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="status uk-margin-small-right"></span>
                                    <?php else: ?>
                                        <span class="status default"></span>
                                    <?php endif; ?>
                                </td>
                                <td class="width-content"><a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->id])); ?>" class="uk-button">Просмотреть</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="uk-margin-large-top">
                    <?php echo e($items->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-white boxed">
                    <span class="uk-text-small uk-text-uppercase">Список <?php echo e(($type == 'income') ? 'входящих' : 'исходящих'); ?> документов корреспонденции пуст</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>