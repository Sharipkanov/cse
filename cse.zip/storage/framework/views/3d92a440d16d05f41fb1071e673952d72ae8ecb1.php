<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                    <?php if(auth()->user()->position_id == 4 && $item->status == 0): ?>
                        <form action="<?php echo e(route('page.correspondence.edit', ['correspondence' => $item->id])); ?>" class="uk-display-inline" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="register" value="1">
                            <button type="submit" class="uk-button uk-button-success">Зарегистрировать</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('page.expertise.list')); ?>" class="uk-button uk-button-primary">К списку экспертиз</a>
                </div>
            </div>

            <?php if($item->status == 3): ?>
                <form id="approve" action="<?php echo e(route('page.document.approve.add', ['document' => $item->id])); ?>" class="uk-form uk-margin-top uk-hidden" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="approve_add" value="1">
                    
                    <hr>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Отправить на согласование</button>
                    </div>
                </form>
            <?php endif; ?>

            <div class="uk-form uk-margin-top uk-margin-large-bottom">
                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>

                <hr>

                <?php if($item->register_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Регистрационный номер:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->register_number); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Язык обращения:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->language()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Корреспондент:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->correspondent()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">ФИО исполнителя:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->executor_fullname); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($item->outcome_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Исходящий №:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->outcome_number); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->outcome_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Дата исходящего:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->outcome_date); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->execution_period): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Срок исполнения:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->execution_period); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->recipent_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Получатель:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->recipent()->last_name .' '. str_limit($item->recipent()->first_name, 1, '.') . str_limit($item->recipent()->middle_name, 1, '')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->reply_correspondence_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Ответ на исходящий:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->reply_correspondence()->register_number); ?> <a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->reply_correspondence()->id])); ?>">Просмотреть</a></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->document_type_id && $item->is_income): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Тип документа:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->document_type()->name); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Страницы:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->pages); ?></p>
                        </div>
                    </div>
                </div>

                <?php if(!$item->is_income): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Основание:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><a class="uk-button uk-button-success" href="<?php echo e(route('page.document.show', ['document' => $item->document()->id])); ?>">Просмотреть</a></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Приложения</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if(count($item->fileList)): ?>
                                    <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Нет вложенных файлов</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Статус</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p class="fw-flex fw-flex-middle">
                                <?php if($item->status): ?>
                                    <span class="status success uk-margin-small-right"></span>
                                    <span>Зарегистрирован</span>
                                <?php else: ?>
                                    <span class="status warning uk-margin-small-right"></span>
                                    <span>На регистраций</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>