<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                    <div class="uk-flex uk-flex-middle">
                        <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status uk-margin-small-right"></div><small>Зарегистрирован (Не присвоен)</small></div>
                        <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status warning uk-margin-small-right"></div><small>На регистраций</small></div>
                        <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status success uk-margin-small-right"></div><small>Зарегистрирован</small></div>
                    </div>
                </div>
                <div>
                    <?php if(auth()->user()->position_id == 4 && $item->status == 2 && !$item->is_income): ?>
                        <button class="uk-button uk-button-primary" data-uk-toggle="{target:'#register',  animation:'uk-animation-slide-right, uk-animation-slide-right'}">Присвоить решистрационный номер</button>
                    <?php endif; ?>
                    <?php if(auth()->user()->position_id == 2 && $item->status == 1): ?>
                        <button class="uk-button uk-button-primary" data-uk-toggle="{target:'#task-toggle',  animation:'uk-animation-slide-right, uk-animation-slide-right'}">Создать карточку задания</button>
                    <?php endif; ?>
                </div>
            </div>

            <?php if(auth()->user()->position_id == 4 && $item->status == 2 && !$item->is_income): ?>
                <form id="register" action="<?php echo e(route('page.correspondence.edit', ['correspondence' => $item->id])); ?>" class="uk-form uk-margin-top uk-hidden" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="register" value="1">
                    <div class="uk-margin-top">
                        <label class="uk-form-label">Регистрационный номер</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <select class="uk-width-1-1" name="register_number">
                                <option value="0">Не выбрано</option>
                                <?php if(count($register_numbers)): ?>
                                    <?php $__currentLoopData = $register_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register_number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($register_number->number); ?>" <?php echo e((old('register_number') == $register_number->number) ? 'selected' : ''); ?>><?php echo e($register_number->number); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="uk-text-right uk-margin-top">
                        <button type="submit" class="uk-button uk-button-success">Зарегистрировать</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if(auth()->user()->position_id == 2 && $item->status == 1): ?>
                <div id="task-toggle" class="uk-margin-top <?php echo e(($errors->any()) ? '' : ' uk-hidden'); ?>">
                    <form action="<?php echo e(route('page.task.correspondence.store')); ?>" class="uk-form" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="correspondence_id" value="<?php echo e($item->id); ?>">
                        <?php if($departments): ?>
                            <div class="uk-form-row">
                                <label class="uk-form-label">Укажите срок исполнения</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select name="executor_id" class="uk-width-1-1">
                                        <option value="">Выберите исполнителя</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($department->leader_id): ?>
                                                <option value="<?php echo e($department->leader()->id); ?>" <?php echo e((old('executor_id') == $department->leader()->id) ? 'selected' : ''); ?>><?php echo e($department->leader()->last_name); ?> <?php echo e($department->leader()->first_name); ?> <?php echo e($department->leader()->middle_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->has('executor_id')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('executor_id')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите срок исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" value="<?php echo e(old('execution_date')); ?>" class="uk-width-1-1" name="execution_date" placeholder="Выберите cрок исполнения" data-uk-datepicker="{minDate: '<?php echo e(date('Y-m-d')); ?>', <?php echo e((($item->execution_period) ? 'maxDate: '. '"' . $item->execution_period .'",' : '')); ?> format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_date')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_date')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите время исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text"  value="<?php echo e(old('execution_time')); ?>" class="uk-width-1-1" name="execution_time" placeholder="Выберите время исполнения" data-uk-timepicker="{start: 9, end: 18}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_time')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_time')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Информация задания</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <textarea name="info" rows="10" class="uk-width-1-1" placeholder="Введите текст задания"><?php echo e(old('info')); ?></textarea>
                            </div>
                        </div>
                        <?php if($errors->has('info')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row uk-text-right">
                            <button type="submit" class="uk-button uk-button-success">Создать</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <div class="uk-form uk-margin-top uk-margin-large-bottom">
                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>

                <hr>

                <?php if($item->register_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Регистрационный номер:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->register_number); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Язык обращения:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->language()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Корреспондент:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->correspondent()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">ФИО исполнителя:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->executor_fullname); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($item->outcome_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Исходящий №:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->outcome_number); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->outcome_number): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Дата исходящего:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->outcome_date); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->execution_period): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Срок исполнения:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->execution_period); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->recipent_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Получатель:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->recipent()->last_name .' '. str_limit($item->recipent()->first_name, 1, '.') . str_limit($item->recipent()->middle_name, 1, '')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->document_type_id && $item->is_income): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Тип документа:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->document_type()->name); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Страницы:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->pages); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($item->reply_correspondence_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Ответ на <?php echo e(($item->is_income) ? 'исходящий' : 'входящий'); ?>:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->reply_correspondence()->id])); ?>">Просмотреть</a></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->is_income): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Приложения</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if(count($item->fileList)): ?>
                                    <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Нет вложенных файлов</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Основание:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><a href="<?php echo e(route('page.document.show', ['document' => $item->document()->id])); ?>">Просмотреть</a></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Статус</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p class="fw-flex fw-flex-middle">
                                <?php if($item->status == 3): ?>
                                    <span class="status success uk-margin-small-right"></span>
                                <?php elseif($item->status == 2): ?>
                                    <span class="status warning uk-margin-small-right"></span>
                                <?php elseif($item->status == 1): ?>
                                    <span class="status uk-margin-small-right"></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>