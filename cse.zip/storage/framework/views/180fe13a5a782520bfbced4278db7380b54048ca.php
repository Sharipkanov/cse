<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <?php if(auth()->user()->position_id == 1): ?>
                <div class="uk-flex uk-flex-middle uk-flex-space-between">
                    <div>
                        <a href="<?php echo e(route('page.department.create')); ?>" class="uk-button uk-button-primary">Создать отдел</a>
                        <a href="<?php echo e(route('page.subdivision.create')); ?>" class="uk-button uk-button-primary">Создать подотдел</a>
                    </div>
                    <div>
                        <a href="<?php echo e(route('page.user.create')); ?>" class="uk-button uk-button-primary">Добавить сотрудника</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="uk-width-1-1 uk-margin-top uk-margin-large-bottom">
        <div class="uk-container uk-container-center">
            <div class="uk-form">
                <h3><?php echo e($name); ?></h3>
                <h4 class="uk-margin-top">Директор: <?php echo e($director->last_name .' '. $director->first_name .' '. $director->middle_name); ?></h4>
                <ul class="uk-tab" data-uk-tab="{connect:'#departments-switcher', animation: 'slide-right'}">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href=""><?php echo e($department->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <ul id="departments-switcher" class="uk-switcher uk-margin">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php if($department->leader_id): ?>

                                <?php $departmentLeader = $department->leader(); ?>
                                <?php if($departmentLeader): ?>
                                    <h4>Начальник отдела: <?php echo e($departmentLeader->last_name .' '. str_limit($departmentLeader->first_name, 1, '.') . str_limit($departmentLeader->middle_name, 1, '')); ?> (<?php echo e($departmentLeader->position()->name); ?>)</h4>
                                <?php endif; ?>
                                <hr>
                                <?php $departmentUsers = $department->department_users(true); ?>
                            <?php else: ?>
                                <?php $departmentUsers = $department->department_users(); ?>
                            <?php endif; ?>
                            <?php if(count($departmentUsers)): ?>
                                <table class="uk-table uk-table-condensed">
                                    <thead>
                                    <tr>
                                        <th>ФИО сотрудника</th>
                                        <th class="width-content">Должность</th>
                                        <th class="width-content"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $departmentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($departmentUser->last_name .' '. str_limit($departmentUser->first_name, 1, '.') . str_limit($departmentUser->middle_name, 1, '')); ?></td>
                                            <td class="width-content"><?php echo e(($departmentUser->position()) ? $departmentUser->position()->name : ''); ?></td>
                                            <td class="width-content"><a href="#" class="uk-button uk-button-success uk-button-small">Просмотреть</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                            <?php if($department->has_subdivision()): ?>
                                <div>
                                    <?php $departmentSubdivision = $department->subdivisions(); ?>
                                    <?php if(count($departmentSubdivision)): ?>
                                        <div class="uk-grid uk-margin-top">
                                            <div class="uk-width-2-6">
                                                <ul class="uk-tab uk-tab-left" data-uk-switcher="{connect:'#subdivision-<?php echo e($department->id); ?>', animation: 'slide-right'}">
                                                    <?php $__currentLoopData = $departmentSubdivision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdivision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href=""><?php echo e($subdivision->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <div class="uk-width-4-6">
                                                <ul class="uk-switcher" id="subdivision-<?php echo e($department->id); ?>">
                                                    <?php $__currentLoopData = $departmentSubdivision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdivision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <?php $subdivisionLeader = $subdivision->leader(); ?>
                                                            <?php if($subdivisionLeader): ?>
                                                                <h5>Начальник подотдела: <?php echo e($subdivisionLeader->last_name .' '. str_limit($subdivisionLeader->first_name, 1, '.') . str_limit($subdivisionLeader->middle_name, 1, '')); ?> (<?php echo e($subdivisionLeader->position()->name); ?>)</h5>
                                                                <hr>
                                                            <?php endif; ?>
                                                            <?php $subdivionUsers = $subdivision->subdivision_users(); ?>
                                                            <?php if($subdivionUsers): ?>
                                                                <?php $subdivionUsers = $subdivision->subdivision_users(); ?>
                                                                <?php if(count($subdivionUsers)): ?>
                                                                    <table class="uk-table uk-table-condensed">
                                                                        <thead>
                                                                        <tr>
                                                                            <th>ФИО сотрудника</th>
                                                                            <th class="width-content">Должность</th>
                                                                            <th class="width-content"></th>
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                        <?php $__currentLoopData = $subdivionUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdivisionUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td><?php echo e($subdivisionUser->last_name .' '. str_limit($subdivisionUser->first_name, 1, '.') . str_limit($subdivisionUser->middle_name, 1, '')); ?></td>
                                                                                <td class="width-content"><?php echo e(($subdivisionUser->position()) ? $subdivisionUser->position()->name : ''); ?></td>
                                                                                <td class="width-content"><a href="#" class="uk-button uk-button-success uk-button-small">Просмотреть</a></td>
                                                                            </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </tbody>
                                                                    </table>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>