<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                    <?php if($item->author()->id == auth()->user()->id && $item->status == 0): ?>
                        <button data-uk-toggle="{target:'#approve', animation:'uk-animation-slide-right, uk-animation-slide-right'}" class="uk-button uk-button-primary" data-uk-modal>Соглосовать</button>
                    <?php endif; ?>
                    <?php if($item->status == 2 && auth()->user()->id == $item->author()->id && !$item->correspondence() && !$item->task_id): ?>
                        <button data-uk-toggle="{target:'#task', animation:'uk-animation-slide-right, uk-animation-slide-right'}" class="uk-button uk-button-primary" data-uk-modal>Прикрепить карточку задания</button>
                    <?php endif; ?>
                    <?php if(auth()->user()->id == $item->author()->id && $item->status > 2): ?>
                        <form action="<?php echo e(route('page.document.copy', ['document' => $item->id])); ?>" method="post" class="uk-display-inline">
                            <?php echo e(csrf_field()); ?>

                            <button  type="submit" class="uk-button">Создать копию</button>
                        </form>
                    <?php endif; ?>
                    <?php if($item->status == 2 && auth()->user()->id == $item->author()->id && !$item->correspondence()): ?>
                        <a href="<?php echo e(route('page.correspondence.outcome.create', ['document' => $item->id])); ?>" class="uk-button uk-button-success">Создать исходящий</a>
                    <?php endif; ?>
                    <?php if($item->correspondence()): ?>
                        <a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->correspondence()->id])); ?>" class="uk-button uk-button-success">Просмотреть исходящую карточку</a>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('page.document.list')); ?>" class="uk-button uk-button-primary">К списку документов</a>
                </div>
            </div>

            <?php if($item->status == 0): ?>
                <form id="approve" action="<?php echo e(route('page.document.approve.add', ['document' => $item->id])); ?>" class="uk-form uk-margin-top uk-hidden" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="approve_add" value="1">
                    <?php $__currentLoopData = array_reverse($leaders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="uk-form-row">
                            <label class="uk-flex uk-flex-middle">
                                <span class="uk-margin-small-right"><input type="checkbox" name="approvers[]" value="<?php echo e($leader->id); ?>"></span>
                                <span><?php echo e($leader->last_name); ?> <?php echo e($leader->first_name); ?> <?php echo e($leader->middle_name); ?></span>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Отправить на согласование</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if(!$item->task_id): ?>
                <form id="task" action="<?php echo e(route('page.document.task.set', ['document' => $item->id])); ?>" class="uk-form uk-margin-top uk-hidden" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="task_id" value="">
                    <div class="uk-margin-top uk-position-relative">
                        <label class="uk-form-label">Карточка задания:</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <input type="text" name="" id="task-search-input" placeholder="Введите регистрационный номер картички" class="uk-width-1-1<?php echo e(($errors->has('task_id')) ? ' uk-form-danger' : ''); ?>">
                            <input type="hidden" name="task_id"  value="" id="task-input">
                        </div>
                        <div class="drop-down" id="task-drop-down">

                        </div>
                    </div>
                    <hr>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Присвоить карточку задания</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if($approve): ?>
                <form action="<?php echo e(route('page.document.approve.answer', ['document' => $item->id, 'approve' => $approve->id])); ?>" class="uk-form uk-margin-top" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="approve_answer" value="1">
                    <div class="uk-form-row">
                        <label class="uk-flex uk-flex-middle approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="1"></span>
                            <span>Соглосовать</span>
                        </label>
                        <label class="uk-flex uk-flex-middle uk-margin-small-top approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="2"></span>
                            <span>Соглосовать с примичанием</span>
                        </label>
                        <label class="uk-flex uk-flex-middle uk-margin-small-top approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="3"></span>
                            <span>Отклонить</span>
                        </label>
                    </div>
                    <div class="uk-form-row uk-hidden" id="approve-info">
                        <div class="uk-form-controls uk-margin-small-top">
                            <textarea name="info" class="uk-width-1-1" rows="6" placeholder="Примичание"></textarea>
                        </div>
                    </div>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Ответить</button>
                    </div>
                </form>
            <?php endif; ?>

            <form class="uk-form uk-margin-top uk-margin-large-bottom" action="<?php echo e(route('page.document.update', ['document' => $item->id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>
                <hr>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Автор</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->author()->last_name); ?> <?php echo e($item->author()->first_name); ?> <?php echo e($item->author()->middle_name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold"><?php echo e(($item->author()->subdivision_id) ? 'Подразделение автора' : 'Отдел автора'); ?></p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($item->author()->subdivision_id) ? $item->author()->subdivision()->name : $item->author()->department()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Тема документа</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дополнительная информация</p>
                        </div>
                        <div class="uk-width-4-6">
                            <?php if($item->status == 4): ?>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <textarea name="info" class="uk-width-1-1<?php echo e($errors->has('info') ? ' uk-form-danger' : ''); ?>" rows="9"><?php echo e(old('info')); ?></textarea>
                                </div>
                                <?php if($errors->has('info')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p><?php echo e($item->info); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Приложения</p>
                        </div>
                        <div class="uk-width-4-6">
                            <?php if($item->status == 4): ?>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="file" name="files[]" multiple>
                                </div>
                                <?php if($errors->has('file')): ?>
                                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('file')); ?></p>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(count($item->fileList)): ?>
                                    <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Нет вложенных файлов</p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Основание:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p>
                                <?php if(!$item->task_id): ?>
                                    Нет основания
                                <?php else: ?>
                                    <a class="" href="<?php echo e(route('page.task.show', ['task' => $item->task()->id])); ?>">Просмотреть</a>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php if($item->status && $item->status == 4): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6"></div>
                            <div class="uk-width-4-6 uk-text-right">
                                <button type="submit" class="uk-button uk-button-success">Сохранить</button>
                            </div>
                        </div>
                    </div>
                <?php elseif($item->status != 0): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Статус</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p class="fw-flex fw-flex-middle">
                                    <?php if($item->status == 3): ?>
                                        <span class="status danger uk-margin-small-right"></span>
                                        <span>Не прошел соглосования</span>
                                    <?php elseif($item->status == 2): ?>
                                        <span class="status success uk-margin-small-right"></span>
                                        <span>Согласован</span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="status warning uk-margin-small-right"></span>
                                        <span>На соглосавиний</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->parent_id && $item->status != 4): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Копия документа</p>
                            </div>
                            <div class="uk-width-4-6">
                                <a href="<?php echo e(route('page.document.show', ['document' => $item->copy()->id])); ?>" target="_blank"><?php echo e($item->copy()->type()->name .': № '. $item->copy()->register_number); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(count($approves)): ?>
                    <hr>
                    <?php $__currentLoopData = $approves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e((!$loop->first) ? 'uk-margin-top' : ''); ?>">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold"><?php echo e($approve->approver()->last_name .' '. str_limit($approve->approver()->first_name, 1, '.') . str_limit($approve->approver()->middle_name, 1, '')); ?></p>
                                </div>
                                <div class="uk-width-4-6">
                                    <?php if($approve->status == 0): ?>
                                        <p>Ожидает</p>
                                    <?php elseif($approve->status == 1): ?>
                                        <p>Соглосован</p>
                                    <?php elseif($approve->status == 2): ?>
                                        <p>Соглосован с примичанием</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php elseif($approve->status == 3): ?>
                                        <p>Отклонен</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>