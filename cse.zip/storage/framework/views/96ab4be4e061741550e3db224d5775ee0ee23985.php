<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-text-right">
                <a href="<?php echo e(route('page.document.list')); ?>" class="uk-button uk-button-primary">К списку документов</a>
            </div>

            <form action="<?php echo e(route('page.document.store')); ?>" class="uk-form uk-margin-top uk-margin-large-bottom" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <h3><?php echo e($title); ?></h3>
                    <hr>
                    <div class="uk-form-row">
                        <label class="uk-form-label">Тема документа</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <input type="text" placeholder="Введите тему документа" class="uk-width-1-1<?php echo e($errors->has('name') ? ' uk-form-danger' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>">
                        </div>
                    </div>
                    <?php if($errors->has('name')): ?>
                        <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('name')); ?></p>
                    <?php endif; ?>
                    <div class="uk-form-row">
                        <label class="uk-form-label">Тип документа</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <select class="uk-width-1-1<?php echo e($errors->has('document_type_id') ? ' uk-form-danger' : ''); ?>" name="document_type_id">
                                <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($documentType->id); ?>" <?php echo e((old('document_type_id') == $documentType->id) ? 'selected' : ''); ?>><?php echo e($documentType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php if($errors->has('document_type_id')): ?>
                        <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('document_type_id')); ?></p>
                    <?php endif; ?>
                    <div class="uk-form-row">
                        <div class="uk-grid uk-grid-width-1-2">
                            <div>
                                <label class="uk-form-label">Номенклатурное дело</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select class="uk-width-1-1" name="nomenclature_id" data-switcher-select="nomenclature-code">
                                        <?php $__currentLoopData = $nomenclatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomenclature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($nomenclature->id); ?>" <?php echo e((old('nomenclature_id') == $nomenclature->id) ? 'selected' : ''); ?>><?php echo e($nomenclature->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label class="uk-form-label">Номенклатурный код</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select class="uk-width-1-1" id="nomenclature-code" data-disabled-select>
                                        <?php $__currentLoopData = $nomenclatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomenclature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($nomenclature->id); ?>" <?php echo e((old('nomenclature_id') == $nomenclature->id) ? 'selected' : ''); ?>><?php echo e($nomenclature->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($errors->has('nomenclature_id')): ?>
                        <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('nomenclature_id')); ?></p>
                    <?php endif; ?>
                    <div class="uk-form-row">
                        <label class="uk-form-label">Дополнительная информация</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <textarea name="info" class="uk-width-1-1<?php echo e($errors->has('info') ? ' uk-form-danger' : ''); ?>" rows="9" placeholder="Введите дополнительная информация"><?php echo e(old('info')); ?></textarea>
                        </div>
                    </div>
                    <?php if($errors->has('info')): ?>
                        <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                    <?php endif; ?>
                    <div class="uk-form-row">
                        <label class="uk-form-label">Приложения</label>
                        <div class="uk-form-controls uk-margin-small-top">
                            <input type="file" name="files[]" multiple>
                        </div>
                    </div>
                    <?php if($errors->has('files')): ?>
                        <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('files')); ?></p>
                    <?php endif; ?>
                    <hr>
                    <div class="uk-text-right">
                        <button type="submit" class="uk-button uk-button-success">Создать документ</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>