<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="b-login">
        <form class="uk-form" action="<?php echo e(route('login.action')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <fieldset>
                <div class="uk-form-row">
                    <input type="text" placeholder="Почта" class="uk-width-1-1<?php echo e($errors->has('email') ? ' uk-form-danger' : ''); ?>" value="<?php echo e(old('email')); ?>" name="email">
                </div>
                <?php if($errors->has('email')): ?>
                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
                <div class="uk-form-row">
                    <input type="password" placeholder="Пароль" class="uk-width-1-1<?php echo e($errors->has('password') ? ' uk-form-danger' : ''); ?>" name="password">
                </div>
                <?php if($errors->has('password')): ?>
                    <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
                
                <div class="uk-form-row">
                    <button type="submit" class="uk-button uk-button-primary uk-width-1-1">Войти в систему</button>
                </div>
            </fieldset>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>