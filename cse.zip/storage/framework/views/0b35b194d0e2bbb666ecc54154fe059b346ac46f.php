<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <?php echo $__env->make('includes.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="uk-margin-top uk-width-1-1">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-middle uk-flex-space-between">
                <div class="uk-flex uk-flex-middle">
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status default uk-margin-small-right"></div><small>Не присвоен</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status uk-margin-small-right"></div><small>На исполнении</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status warning uk-margin-small-right"></div><small>На регистраций</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status success uk-margin-small-right"></div><small>Зарегистрирован</small></div>
                </div>
                <div>
                    <?php if($type == 'income' && auth()->user()->position_id == 4): ?>
                        <a href="<?php echo e(route('page.correspondence.income.create')); ?>" class="uk-button uk-button-success">Создать регистрационную карточку входящего документа</a>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">

            <?php if(count($items)): ?>
                <table class="uk-table uk-table-condensed">
                    <thead>
                        <tr>
                            <th class="width-content">Регистрационный номер</th>
                            <th>ФИО исполнителя</th>
                            <th class="width-content">Корреспондент</th>
                            <th class="width-content">Дата регистрации</th>
                            <th class="width-content"></th>
                            <th class="width-content"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="width-content"><?php echo e($item->register_number); ?></td>
                                <td><?php echo e($item->executor_fullname); ?></td>
                                <td class="width-content"><?php echo e($item->correspondent()->name); ?></td>
                                <td class="width-content"><?php echo e($item->created_at); ?></td>
                                <td class="width-content uk-text-center">
                                    <?php if($item->status == 3): ?>
                                        <span class="status success uk-margin-small-right"></span>
                                    <?php elseif($item->status == 2): ?>
                                        <span class="status warning uk-margin-small-right"></span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="status uk-margin-small-right"></span>
                                    <?php else: ?>
                                        <span class="status default"></span>
                                    <?php endif; ?>
                                </td>
                                <td class="width-content"><a href="<?php echo e(route('page.correspondence.show', ['correspondence' => $item->id])); ?>" class="uk-button">Просмотреть</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="uk-margin-large-top">
                    <?php echo e($items->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-white boxed uk-margin-top">
                    <span class="uk-text-small uk-text-uppercase">Список <?php echo e(($type == 'income') ? 'входящих' : 'исходящих'); ?> документов корреспонденции пуст</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>