<p>Новое задание</p>
<p>Пройдите пожалуйста по <a href="<?php echo e($url); ?>" target="_blank">ссылке</a></p>