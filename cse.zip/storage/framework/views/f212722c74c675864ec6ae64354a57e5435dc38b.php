<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <?php if(session()->has('success')): ?>
        <div class="uk-width-1-1 uk-margin-top">
            <div class="uk-container uk-container-center">
                <span class="h4 uk-text-success">Пользоватедь успешно создан</span>
            </div>
        </div>
    <?php endif; ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <form action="<?php echo e(route('page.user.store')); ?>" class="uk-form uk-margin-large-bottom" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <h3><?php echo e($title); ?></h3>
                    <hr>
                    <div class="uk-grid uk-grid-width-1-2">
                        <div>
                            <div>
                                <label class="uk-form-label">Фамилия:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1<?php echo e($errors->has('last_name') ? ' uk-form-danger' : ''); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>">
                                </div>
                            </div>
                            <?php if($errors->has('last_name')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('last_name')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Имя:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1<?php echo e($errors->has('first_name') ? ' uk-form-danger' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>">
                                </div>
                            </div>
                            <?php if($errors->has('first_name')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('first_name')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Отчество:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1<?php echo e($errors->has('middle_name') ? ' uk-form-danger' : ''); ?>" name="middle_name" value="<?php echo e(old('middle_name')); ?>">
                                </div>
                            </div>
                            <?php if($errors->has('middle_name')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('middle_name')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Электронная почта:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" class="uk-width-1-1<?php echo e($errors->has('email') ? ' uk-form-danger' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>">
                                </div>
                            </div>
                            <?php if($errors->has('email')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div>
                                <label class="uk-form-label">Отдел:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select class="uk-width-1-1<?php echo e(($errors->has('department_id')) ? ' uk-form-danger' : ''); ?>" name="department_id" id="expertise-region-select">
                                        <option value="" <?php echo e((old('department_id') == '') ? 'selected' : ''); ?> disabled>Выберите отдел</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php echo e((old('department_id') == $department->id) ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php if($errors->has('department_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('department_id')); ?></p>
                            <?php endif; ?>
                            <div class="uk-margin-top">
                                <label class="uk-form-label">Подотдел:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select class="uk-width-1-1<?php echo e(($errors->has('subdivision_id')) ? ' uk-form-danger' : ''); ?>" name="subdivision_id">
                                        <option value="">Выберите пододел</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="" disabled><?php echo e($department->name); ?></option>
                                            <?php $__currentLoopData = $department->subdivisions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdivision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subdivision->id); ?>">-<?php echo e($subdivision->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php if($errors->has('subdivision_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('subdivision_id')); ?></p>
                            <?php endif; ?>

                            <div class="uk-margin-top">
                                <label class="uk-form-label">Должность:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select name="position_id" class="uk-width-1-1<?php echo e($errors->has('position_id') ? ' uk-form-danger' : ''); ?>">
                                        <option value="">Выберите должность</option>
                                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($position->id); ?>"><?php echo e($position->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php if($errors->has('position_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('position_id')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr>
                    <div class="uk-text-right">
                        <button type="submit" class="uk-button uk-button-success">Создать пользователя</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>