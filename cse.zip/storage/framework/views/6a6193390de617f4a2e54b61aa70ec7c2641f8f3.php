<div class="uk-width-1-1">
    <nav class="uk-navbar">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between uk-flex-middle">
                <ul class="uk-navbar-nav">
                    <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(($item->current) ? 'uk-active' : ''); ?>"><a href="<?php echo e($item->url); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div>
                    <button class="uk-button" data-uk-toggle="{target:'#add-correspondent', animation:'uk-animation-slide-right, uk-animation-slide-right'}">Добавить корреспондента</button>
                </div>
            </div>
        </div>
    </nav>
</div>