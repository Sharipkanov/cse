<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <form action="<?php echo e(route('page.correspondence.store.outcome')); ?>" class="uk-form uk-margin-top uk-margin-large-bottom" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <h3><?php echo e($title); ?></h3>
                    <hr>
                    <div>
                        <div>
                            <label class="uk-form-label">Язык обращения:</label>
                            <div class="uk-form-controls uk-margin-small-top uk-flex">
                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="<?php echo e(($loop->first) ? 'uk-margin-right' : ''); ?>">
                                        <label class="uk-flex uk-flex-middle">
                                    <span class="uk-margin-small-right">
                                        <input type="radio" name="language_id" value="<?php echo e($language->id); ?>" <?php echo e((old('language_id') == $language->id) ? 'checked' : ''); ?>>
                                    </span>
                                            <span><?php echo e($language->name); ?></span>
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php if($errors->has('language_id')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('language_id')); ?></p>
                        <?php endif; ?>

                        <?php if($correspondence): ?>
                            <div class="uk-margin-top">
                                <label class="uk-form-label">Корреспондент:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="hidden" name="correspondent_id" value="<?php echo e($correspondence->correspondent()->id); ?>">
                                    <input name="" class="uk-width-1-1" value="<?php echo e($correspondence->correspondent()->name); ?>" readonly>
                                </div>
                            </div>
                            <div class="uk-margin-top">
                                <label class="uk-form-label">Ответ на входящий:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="hidden" name="reply_correspondence_id" value="<?php echo e($correspondence->id); ?>">
                                    <input name="" class="uk-width-1-1" value="<?php echo e($correspondence->register_number); ?>" readonly>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="uk-margin-top uk-position-relative">
                                <label class="uk-form-label">Корреспондент:</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <input type="text" name="" id="correspondent-search-input" placeholder="Введите имя корреспондента" class="uk-width-1-1<?php echo e(($errors->has('correspondent_id')) ? ' uk-form-danger' : ''); ?>">
                                    <input type="hidden" name="correspondent_id"  value="" id="correspondent-input">
                                </div>
                                <div class="drop-down" id="correspondent-drop-down">

                                </div>
                            </div>
                            <?php if($errors->has('correspondent_id')): ?>
                                <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('correspondent_id')); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>

                        <div class="uk-margin-top">
                            <label class="uk-form-label">Страницы:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input name="pages" class="uk-width-1-1<?php echo e($errors->has('pages') ? ' uk-form-danger' : ''); ?>" value="<?php echo e(old('info')); ?>" placeholder="Введите количество страниц">
                            </div>
                        </div>
                        <?php if($errors->has('pages')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('pages')); ?></p>
                        <?php endif; ?>

                        <div class="uk-margin-top">
                            <label class="uk-form-label">ФИО исполнителя:</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input name="executor_fullname" class="uk-width-1-1" value="<?php echo e($document->author()->last_name .' '. $document->author()->first_name .' '. $document->author()->middle_name); ?>" readonly>
                            </div>
                        </div>
                        <div class="uk-margin-top">
                            <label class="uk-form-label">Тип документа</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" value="<?php echo e($document->type()->name); ?>" readonly name="" class="uk-width-1-1">
                                <input type="hidden" name="document_type_id" value="<?php echo e($document->type()->id); ?>">
                                <input type="hidden" name="document_id" value="<?php echo e($document->id); ?>">
                            </div>
                        </div>
                        <div class="uk-margin-top">
                            <label class="uk-form-label">Основание</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <a href="<?php echo e(route('page.document.show', ['document' => $document->id])); ?>">Просмотреть</a>
                            </div>
                        </div>
                    </div>
                    <div class="uk-text-right uk-margin-top">
                        <button type="submit" class="uk-button uk-button-success">Создать карточку</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>