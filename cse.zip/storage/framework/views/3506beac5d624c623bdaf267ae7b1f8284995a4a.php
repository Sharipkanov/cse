<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/uikit.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/form-advanced.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/form-file.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/form-password.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/datepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/accordion.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="app-wrapper uk-flex uk-flex-column">
        <header class="uk-width-1-1">
            <div class="uk-navbar uk-navbar--dark">
                <div class="uk-container uk-container-center">
                    <a href="<?php echo e(route('page.home')); ?>" class="uk-navbar-brand">
                        <span class="uk-height-1-1 uk-flex uk-flex-middle">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="uk-margin-small-right">
                            <span>CSE</span>
                        </span>
                    </a>
                    <div class="uk-navbar-flip">
                        <form action="<?php echo e(route('logout.action')); ?>" class="uk-display-inline" method="post">
                            <span><?php echo e(auth()->user()->last_name .' '. str_limit(auth()->user()->first_name, 1, '.') . str_limit(auth()->user()->middle_name, 1, '')); ?></span>
                            <span class="uk-margin-small-right uk-margin-small-left">|</span>
                            <?php echo e(csrf_field()); ?>

                            <button class="uk-button-link" type="submit">Выход</button>
                        </form>
                    </div>
                </div>
            </div>
        </header>

        <?php echo $__env->yieldContent('page'); ?>

        <footer class="uk-width-1-1">
            <div class="uk-container uk-container-center">
                <p class="uk-margin-small-top uk-margin-small-bottom uk-flex uk-flex-middle">
                    <i class="uk-icon-copyright uk-margin-small-right"></i>
                    <span class="uk-text-small">Все права защищены CSE 2017</span>
                </p>
            </div>
        </footer>
    </div>

    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/uikit.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/components/autocomplete.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/components/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/components/accordion.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/components/timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>