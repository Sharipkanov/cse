<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-middle uk-flex-space-between">
                <div class="uk-margin-top uk-flex uk-flex-middle">
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status warning uk-margin-small-right"></div><small>На исполнении</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status success uk-margin-small-right"></div><small>Исполнено</small></div>
                    <div class="uk-flex uk-flex-middle uk-margin-right"><div class="status danger uk-margin-small-right"></div><small>Просрочено</small></div>
                </div>
                <div>
                    <?php if(auth()->user()->position_id == 2): ?>
                        <button class="uk-button uk-button-primary" data-uk-toggle="{target:'#task-toggle',  animation:'uk-animation-slide-right, uk-animation-slide-right'}">Создать карточку задания</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(auth()->user()->position_id == 2): ?>
                <div id="task-toggle" class="uk-margin-top <?php echo e(($errors->any()) ? '' : ' uk-hidden'); ?>">
                    <form action="<?php echo e(route('page.task.store')); ?>" class="uk-form" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php if($departments): ?>
                            <div class="uk-form-row">
                                <label class="uk-form-label">Укажите срок исполнения</label>
                                <div class="uk-form-controls uk-margin-small-top">
                                    <select name="executor_id" class="uk-width-1-1">
                                        <option value="">Выберите исполнителя</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($department->leader_id): ?>
                                                <option value="<?php echo e($department->leader()->id); ?>" <?php echo e((old('executor_id') == $department->leader()->id) ? 'selected' : ''); ?>><?php echo e($department->leader()->last_name); ?> <?php echo e($department->leader()->first_name); ?> <?php echo e($department->leader()->middle_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->has('executor_id')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('executor_id')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите срок исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text" value="<?php echo e(old('execution_date')); ?>" class="uk-width-1-1" name="execution_date" placeholder="Выберите cрок исполнения" data-uk-datepicker="{minDate: '<?php echo e(date('Y-m-d')); ?>', format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_date')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_date')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Укажите время исполнения</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <input type="text"  value="<?php echo e(old('execution_time')); ?>" class="uk-width-1-1" name="execution_time" placeholder="Выберите время исполнения" data-uk-timepicker="{start: 9, end: 18}">
                            </div>
                        </div>
                        <?php if($errors->has('execution_time')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('execution_time')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row">
                            <label class="uk-form-label">Информация задания</label>
                            <div class="uk-form-controls uk-margin-small-top">
                                <textarea name="info" rows="10" class="uk-width-1-1" placeholder="Введите текст задания"><?php echo e(old('info')); ?></textarea>
                            </div>
                        </div>
                        <?php if($errors->has('info')): ?>
                            <p class="uk-text-small uk-text-danger uk-margin-small"><?php echo e($errors->first('info')); ?></p>
                        <?php endif; ?>
                        <div class="uk-form-row uk-text-right">
                            <button type="submit" class="uk-button uk-button-success">Создать</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            <?php if(count($items)): ?>
                <form class="uk-form uk-margin-top" method="get">
                    <?php echo e(csrf_field()); ?>

                    <div class="uk-flex">
                        <div class="uk-flex-item-auto uk-margin-small-right">
                            <input type="text" name="register_number" placeholder="Регистрационный номер" class="uk-width-1-1">
                        </div>
                        <div class="uk-flex-item-auto uk-margin-small-right">
                            <input type="text" class="uk-width-1-1" placeholder="Дата регистрации" name="date" data-uk-datepicker="{format:'YYYY-MM-DD', i18n: {months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'], weekdays: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб']}}">
                        </div>
                        <div class="uk-flex-item-auto uk-margin-small-right">
                            <input type="text" name="author" placeholder="Автор" class="uk-width-1-1">
                        </div>
                        <div class="uk-flex-item-auto uk-margin-small-right">
                            <input type="text" name="name" placeholder="Тема документа" class="uk-width-1-1">
                        </div>
                        <div class="uk-flex-item-none"><button class="uk-button uk-button-danger">Фильтровать</button></div>
                    </div>
                </form>

                <table class="uk-table uk-table-condensed">
                    <thead>
                    <tr>
                        <th class="width-content">Регистрационный номер</th>
                        <th>Автор</th>
                        <th>Исполнитель</th>
                        <th class="width-content">Срок выполнения</th>
                        <th class="width-content">Дата регистрации</th>
                        <th class="width-content">Статус</th>
                        <th class="width-content"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="width-content"><?php echo e($item->register_number); ?></td>
                            <td><?php echo e($item->author()->last_name .' '. str_limit($item->author()->first_name, 1, '.') . str_limit($item->author()->middle_name, 1, '')); ?></td>
                            <td><?php echo e($item->executor()->last_name .' '. str_limit($item->executor()->first_name, 1, '.') . str_limit($item->executor()->middle_name, 1, '')); ?></td>
                            <td class="width-content"><?php echo e($item->execution_period); ?></td>
                            <td class="width-content"><?php echo e($item->created_at); ?></td>
                            <td class="width-content uk-text-center">
                                <?php if($item->status == 2): ?>
                                    <div class="status danger"></div>
                                <?php elseif($item->status == 1): ?>
                                    <div class="status success"></div>
                                <?php elseif($item->status == 0): ?>
                                    <div class="status warning"></div>
                                <?php endif; ?>
                            </td>
                            <td class="width-content">
                                <a href="<?php echo e(route('page.task.show', ['task' => $item->id])); ?>" class="uk-button uk-button-small">Просмотреть</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="uk-margin-top uk-margin-large-bottom">
                    <?php echo e($items->links()); ?>

                </div>
            <?php else: ?>
                <div class="bg-white boxed uk-margin-top">
                    <span class="uk-text-small uk-text-uppercase">Список карточек задания пуст</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>