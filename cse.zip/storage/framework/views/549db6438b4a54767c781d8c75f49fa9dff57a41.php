<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <?php
    $expertiseInfoCreatedDate = explode(' ', $expertiseInfo->created_at)[0];
    $expertiseUntilSuspensionDate = date('Y-m-d', strtotime($expertiseInfoCreatedDate.' + 5 days'));
    $expertiseOutOfSuspension = strtotime($expertiseUntilSuspensionDate) <= time();
    ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                </div>
                <div>
                    <a href="<?php echo e(route('page.expertise.list')); ?>" class="uk-button uk-button-primary">К списку экспертиз</a>
                </div>
            </div>
            <?php if($approve && $previousApproved): ?>
                <form action="<?php echo e(route('page.expertise.approve.answer', ['expertiseInfo' => $expertiseInfo->id, 'expertiseApprove' => $approve->id])); ?>" class="uk-form uk-margin-top" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="approve_answer" value="1">
                    <div class="uk-form-row">
                        <label class="uk-flex uk-flex-middle approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="1"></span>
                            <span>Соглосовать</span>
                        </label>
                        <label class="uk-flex uk-flex-middle uk-margin-small-top approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="2"></span>
                            <span>Соглосовать с примичанием</span>
                        </label>
                        <label class="uk-flex uk-flex-middle uk-margin-small-top approve-type">
                            <span class="uk-margin-small-right"><input type="radio" name="status" value="3"></span>
                            <span>Отклонить</span>
                        </label>
                    </div>
                    <div class="uk-form-row uk-hidden" id="approve-info">
                        <div class="uk-form-controls uk-margin-small-top">
                            <textarea name="info" class="uk-width-1-1" rows="6" placeholder="Примичание"></textarea>
                        </div>
                    </div>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Ответить</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if(count($approves)): ?>
                <div class="uk-margin-top uk-form">
                    <?php $__currentLoopData = $approves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e((!$loop->first) ? 'uk-margin-top' : ''); ?>">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold"><?php echo e($approve->approver()->last_name .' '. str_limit($approve->approver()->first_name, 1, '.') . str_limit($approve->approver()->middle_name, 1, '')); ?></p>
                                </div>
                                <div class="uk-width-4-6">
                                    <?php if($approve->status == 0): ?>
                                        <p>Ожидает</p>
                                    <?php elseif($approve->status == 1): ?>
                                        <p>Соглосован</p>
                                    <?php elseif($approve->status == 2): ?>
                                        <p>Соглосован с примичанием</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php elseif($approve->status == 3): ?>
                                        <p>Отклонен</p>
                                        <textarea class="uk-width-1-1" rows="7" disabled><?php echo e($approve->info); ?></textarea>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="uk-accordion uk-margin-top uk-margin-bottom" data-uk-accordion="{showfirst: false}">
                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3 uk-accordion-title">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>
                <div class="uk-accordion-content uk-form">
                    <div>
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Делопроизводитель</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->author()->last_name); ?> <?php echo e($item->author()->first_name); ?> <?php echo e($item->author()->middle_name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Фабула</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->info); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Приложения</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if(count($item->fileList)): ?>
                                    <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Нет вложенных файлов</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Категория дела:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->category()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">№ дела:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->case_number); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">№ статьи:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->article_number); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Статус:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->status()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Дополнительный статус:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->addition_status()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Шифр экспертизы:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <ul class="uk-list">
                                    <?php $__currentLoopData = $item->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><span><?php echo e($speciality->code .' - '. $speciality->name); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Регион назначивший экспертизу:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->region()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Наименование органа:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->agency()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Орган назначивший экспертизу:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->organ()->name); ?></p>
                            </div>
                        </div>
                    </div>

                    <?php if($item->expertise_organ_name): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Введите название органа:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_organ_name); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <div class="">
                        <span class="uk-h4">Данные лица назначевшего экспертизу</span>
                    </div>

                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">ФИО:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->expertise_user_fullname); ?></p>
                            </div>
                        </div>
                    </div>


                    <?php if($item->expertise_user_position): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Должность:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_user_position); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($item->expertise_user_rank): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Звание:</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p><?php echo e($item->expertise_user_rank); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($item->status != 0): ?>
                        <div class="uk-margin-top">
                            <div class="uk-grid">
                                <div class="uk-width-2-6">
                                    <p class="uk-text-bold">Статус</p>
                                </div>
                                <div class="uk-width-4-6">
                                    <p class="fw-flex fw-flex-middle">
                                        <?php if($item->status == 2): ?>
                                            <span class="status success uk-margin-small-right"></span>
                                            <span>Завершен</span>
                                        <?php elseif($item->status == 1): ?>
                                            <span class="status warning uk-margin-small-right"></span>
                                            <span>В процесе</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <div class="uk-form uk-margin-bottom">
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Категория сложности:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->category_of_difficulty) ? $expertiseInfo->category_of_difficulty : ''); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Количество поставленных вопросов:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->questions_count) ? $expertiseInfo->questions_count : ''); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Количество объектов :</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->objects_count) ? $expertiseInfo->objects_count : ''); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Срок производства:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->expiration_date) ? $expertiseInfo->expiration_date : ''); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Результата исследования:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->result_of_research) ? $expertiseInfo->result_of_research : ''); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Категорические выводы:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->categorical_conclusions) ? $expertiseInfo->categorical_conclusions : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Вероятные выводы:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->probable_conclusions) ? $expertiseInfo->categorical_conclusions : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">НПВ:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->wnp) ? $expertiseInfo->wnp : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Количество не решенных вопросов :</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->unsolved_issues_count) ? $expertiseInfo->unsolved_issues_count : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дано выводов (ВСЕГО) :</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->conclusions_count) ? $expertiseInfo->conclusions_count : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Категорические выводы (ПОЛОЖИТЕЛЬНЫЕ):</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->categorical_conclusions_positive) ? $expertiseInfo->categorical_conclusions_positive : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Категорические выводы (ОТРИЦАТЕЛЬНЫЕ):</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->categorical_conclusions_negative) ? $expertiseInfo->categorical_conclusions_negative : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Стоимость исследования:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->cost) ? $expertiseInfo->cost : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Отметка об оплате:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->payment_note) ? $expertiseInfo->payment_note : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">№ документа:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->payment_note_document_number) ? $expertiseInfo->payment_note_document_number : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата документа:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->payment_note_document_date) ? $expertiseInfo->payment_note_document_date : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Причины возврата без исполнения:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->return_reason) ? $expertiseInfo->return_reason : ''); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Причины СНДЗ:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->rigs) ? $expertiseInfo->rigs : ''); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="uk-form uk-margin-large-bottom">
                <div class="uk-form-row">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата приостановления</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->suspension_date) ? $expertiseInfo->suspension_date : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Причина приостановления</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->reason_for_suspension) ? $expertiseInfo->reason_for_suspension : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($expertiseInfo->document_id || $expertiseInfo->correspondence_id): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Основание</p>
                            </div>
                            <div class="uk-width-4-6">
                                <?php if($expertiseInfo->document_id): ?>
                                    <a target="_blank" href="<?php echo e(route('page.document.show', ['document' => $expertiseInfo->document_id])); ?>">Просмотреть</a>
                                <?php endif; ?>
                                <?php if($expertiseInfo->correspondence_id): ?>
                                    <a target="_blank" href="<?php echo e(route('page.correspondence.show', ['correspondence' => $expertiseInfo->correspondence_id])); ?>">Просмотреть</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата возобновления </p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->renewal_date) ? $expertiseInfo->renewal_date : 'Еще не был приостановлен'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дата завершения исследования </p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->finish_date) ? $expertiseInfo->finish_date : 'Будет указано после завершения экспертизы'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Фактическое количество дней нахождения материалов в территориальном подразделении</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->actual_days) ? $expertiseInfo->actual_days : 'Экспертиза еще не была завершена'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Количество дней в производстве</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e(($expertiseInfo->production_days) ? $expertiseInfo->production_days : 'Экспертиза еще не была завершена'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>