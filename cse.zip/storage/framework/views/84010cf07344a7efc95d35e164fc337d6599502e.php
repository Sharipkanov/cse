<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/uikit.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/uikit/css/components/form-advanced.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="app-wrapper uk-flex uk-flex-column">
        <?php echo $__env->yieldContent('page'); ?>
    </div>

    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/uikit/js/uikit.min.js')); ?>"></script>
</body>
</html>