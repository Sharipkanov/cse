<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-middle uk-flex-space-between">
                <div>
                    <a href="#department-create" class="uk-button uk-button-primary" data-uk-modal>Создать отдел</a>
                    <a href="#subdivision-create" class="uk-button uk-button-primary" data-uk-modal>Создать подотдел</a>
                </div>
                <div>
                    <a href="<?php echo e(route('page.user.create')); ?>" class="uk-button uk-button-primary">Добавить сотрудника</a>
                </div>
            </div>
        </div>
    </div>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-form">

            </div>
        </div>
    </div>
    <div id="department-create" class="uk-modal">
        <div class="uk-modal-dialog">
            <a class="uk-modal-close uk-close"></a>
            <div>
                Создать отдел
            </div>
        </div>
    </div>

    <div id="subdivision-create" class="uk-modal">
        <div class="uk-modal-dialog">
            <a class="uk-modal-close uk-close"></a>
            <div>
                Создать подотдел
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>