<?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <div class="uk-width-1-1 uk-margin-top">
        <div class="uk-container uk-container-center">
            <div class="uk-flex uk-flex-space-between">
                <div>
                    <?php if(count($executors)): ?>
                        <button data-uk-toggle="{target:'#approve', animation:'uk-animation-slide-right, uk-animation-slide-right'}" class="uk-button uk-button-primary" data-uk-modal>Отправить на поручение</button>
                    <?php endif; ?>
                    <?php if($income_task && $income_task->status == 0 && !$outcome_task): ?>
                        <form action="<?php echo e(route('page.expertise.task.set')); ?>" class="uk-display-inline" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="expertise_task_id" value="<?php echo e($income_task->id); ?>">
                            <button type="submit" class="uk-button uk-button-success">Принять</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('page.expertise.list')); ?>" class="uk-button uk-button-primary">К списку экспертиз</a>
                </div>
            </div>

            <?php if(count($executors)): ?>
                <form id="approve" action="<?php echo e(route('page.expertise.task.store')); ?>" class="uk-form uk-margin-top uk-hidden" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php if($task_parent): ?>
                        <input type="hidden" name="parent_id" value="<?php echo e($task_parent); ?>">
                    <?php endif; ?>
                    <input type="hidden" name="expertise_id" value="<?php echo e($item->id); ?>">
                    <?php $__currentLoopData = $executors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="uk-form-row">
                            <label class="uk-flex uk-flex-middle">
                                <span class="uk-margin-small-right"><input type="checkbox" name="execute[<?php echo e($executor['leader']->id); ?>][executor]" value="<?php echo e($executor['leader']->id); ?>"></span>
                                <span><?php echo e($executor['leader']->last_name); ?> <?php echo e($executor['leader']->first_name); ?> <?php echo e($executor['leader']->middle_name); ?></span>
                            </label>
                            <?php $__currentLoopData = $executor['specialities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="uk-margin-left uk-margin-small-top">
                                    <label class="uk-flex uk-flex-middle">
                                        <span class="uk-margin-small-right"><input type="checkbox" name="execute[<?php echo e($executor['leader']->id); ?>][specialities][]" value="<?php echo e($speciality->id); ?>" class="speciality-checkbox" data-speciality="<?php echo e($speciality->id); ?>"></span>
                                        <span><?php echo e($speciality->code .' - '. $speciality->name); ?></span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="uk-form-row uk-text-right">
                        <button class="uk-button uk-button-success">Поручить</button>
                    </div>
                </form>
            <?php endif; ?>

            <div class="uk-form uk-margin-top uk-margin-large-bottom">
                <span class="uk-flex uk-flex-space-between uk-flex-middle uk-h3">
                    <span><?php echo e($title); ?></span>
                    <span class="uk-h5">Дата создания: <?php echo e($item->created_at); ?></span>
                </span>
                <hr>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Делопроизводитель</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->author()->last_name); ?> <?php echo e($item->author()->first_name); ?> <?php echo e($item->author()->middle_name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Фабула</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->info); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Приложения</p>
                        </div>
                        <div class="uk-width-4-6">
                            <?php if(count($item->fileList)): ?>
                                <?php $__currentLoopData = $item->fileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('page.file.download', ['file' => $file->id])); ?>" target="_blank"><?php echo e($file->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>Нет вложенных файлов</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Категория дела:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->category()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">№ дела:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->case_number); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">№ статьи:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->article_number); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Статус:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->status()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Дополнительный статус:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->addition_status()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Шифр экспертизы:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <ul class="uk-list">
                                <?php $__currentLoopData = $item->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span><?php echo e($speciality->code .' - '. $speciality->name); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Регион назначивший экспертизу:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->region()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Наименование органа:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->agency()->name); ?></p>
                        </div>
                    </div>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">Орган назначивший экспертизу:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->organ()->name); ?></p>
                        </div>
                    </div>
                </div>

                <?php if($item->expertise_organ_name): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Введите название органа:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->expertise_organ_name); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <hr>

                <div class="">
                    <span class="uk-h4">Данные лица назначевшего экспертизу</span>
                </div>

                <div class="uk-margin-top">
                    <div class="uk-grid">
                        <div class="uk-width-2-6">
                            <p class="uk-text-bold">ФИО:</p>
                        </div>
                        <div class="uk-width-4-6">
                            <p><?php echo e($item->expertise_user_fullname); ?></p>
                        </div>
                    </div>
                </div>


                <?php if($item->expertise_user_position): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Должность:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->expertise_user_position); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->expertise_user_rank): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Звание:</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p><?php echo e($item->expertise_user_rank); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($item->status != 0): ?>
                    <div class="uk-margin-top">
                        <div class="uk-grid">
                            <div class="uk-width-2-6">
                                <p class="uk-text-bold">Статус</p>
                            </div>
                            <div class="uk-width-4-6">
                                <p class="fw-flex fw-flex-middle">
                                    <?php if($item->status == 2): ?>
                                        <span class="status success uk-margin-small-right"></span>
                                        <span>Завершен</span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="status warning uk-margin-small-right"></span>
                                        <span>В процесе</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>