<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpertiseType extends Model
{
    //
}
