<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpertiseApprove extends Model
{
    //
}
